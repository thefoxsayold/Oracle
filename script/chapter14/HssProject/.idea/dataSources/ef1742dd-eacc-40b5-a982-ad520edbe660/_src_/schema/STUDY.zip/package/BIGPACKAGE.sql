create package BigPackage
is
type outData is ref cursor;
procedure P_GETEMPLOYESSBYPAGE(p_pagesize int,
                          p_startsize int,
                          out_pagecount out int,
                          out_datacollection out outData) 
as
v_count int;
v_upCount int;
v_lowCount int;
begin
     --获取页面总的记录数
    execute immediate 'select count(*) from EMPLOYEES into v_count';
    out_pagecount:=v_count;
    --获取数据的上下限
    v_upCount:=p_startsize*p_pagesize;   --上限
    v_lowCount:=v_upCount-p_pagesize+1; --下限

    v_sql:='select * from (select a.*,rownum r from EMPLOYEES a where rownum <='||to_char(v_upCount)||') B
               where r>='||to_char(v_lowCount);
    open out_datacollection for v_sql;
end P_GETEMPLOYESSBYPAGE;
end BigPackage;