CREATE PACKAGE MyPack IS
   TYPE refcur is ref cursor;
   FUNCTION Get_SaleAmount(V_DEPARTMENT_ID NUMBER) RETURN NUMBER;
   PROCEDURE Get_Employees(V_EMPLOYEE_ID NUMBER);
   FUNCTION Get_EmployeeByPage(v_pageidx number,v_pagesize number) return refcur;
   PROCEDURE Get_EmployeeByPage_P(v_pageidx number,v_pagesize number,rc out refcur);
   PROCEDURE Calc_All_TradeReceivable;
END MyPack;
/
