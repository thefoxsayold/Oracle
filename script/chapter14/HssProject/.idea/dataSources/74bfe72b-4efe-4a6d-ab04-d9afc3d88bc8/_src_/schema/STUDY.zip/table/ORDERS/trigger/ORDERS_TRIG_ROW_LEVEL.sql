CREATE TRIGGER ORDERS_TRIG_ROW_LEVEL
BEFORE INSERT OR UPDATE OF DISCOUNT
  ON ORDERS
FOR EACH ROW
  declare
  m number(8,2);
BEGIN
  if inserting then
       :new.TRADE_RECEIVABLE := - :new.discount; 
  else
      select sum(PRODUCT_NUM*PRODUCT_PRICE) into m from ORDER_DETAILS where ORDER_ID=:old.ORDER_ID;
      if m is null then
        m:=0;
      end if;
      :new.TRADE_RECEIVABLE := m - :new.discount;
  end if;
END;
/
