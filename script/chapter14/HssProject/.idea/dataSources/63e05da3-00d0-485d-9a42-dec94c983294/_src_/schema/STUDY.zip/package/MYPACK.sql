CREATE PACKAGE MyPack IS
   TYPE refcur is ref cursor;
   FUNCTION Get_SaleAmount(V_DEPARTMENT_ID NUMBER) RETURN NUMBER;
   PROCEDURE Get_Employees(V_EMPLOYEE_ID NUMBER);
   FUNCTION Get_EmployeeByPage(v_pageidx number,v_pagesize number) return refcur;
   PROCEDURE Get_EmployeeByPage_P(v_pageidx number,v_pagesize number,rc out refcur);
   PROCEDURE Calc_All_TradeReceivable;
END MyPack;
/
CREATE PACKAGE BODY MyPack IS
    FUNCTION Get_SaleAmount(V_DEPARTMENT_ID NUMBER) RETURN NUMBER
    AS
      N NUMBER(20,2); --注意，订单ORDERS.TRADE_RECEIVABLE的类型是NUMBER(8,2),汇总之后，数据要大得多。
    BEGIN
      SELECT SUM(O.TRADE_RECEIVABLE) into N  FROM ORDERS O,EMPLOYEES E
        WHERE O.EMPLOYEE_ID=E.EMPLOYEE_ID AND E.DEPARTMENT_ID =V_DEPARTMENT_ID;
      RETURN N;
    END;

    PROCEDURE GET_EMPLOYEES(V_EMPLOYEE_ID NUMBER)
    AS
      LEFTSPACE VARCHAR(2000);
    begin
      --通过LEVEL判断递归的级别
      LEFTSPACE:=' ';
      --使用游标
      for v in
        (SELECT LEVEL,EMPLOYEE_ID,NAME,MANAGER_ID FROM employees 
          START WITH EMPLOYEE_ID = V_EMPLOYEE_ID 
          CONNECT BY PRIOR EMPLOYEE_ID = MANAGER_ID)
      LOOP
        DBMS_OUTPUT.PUT_LINE(LPAD(LEFTSPACE,(V.LEVEL-1)*4,' ')||
          V.EMPLOYEE_ID||' '||v.NAME);
      END LOOP;   
   END;

   /*
   FUNCTION Get_EmployeeByPage（）：分页方法获取员工表
   v_pageidx：页码，从1开始
   v_pagesize：每页的记录数量
   测试方法：
set serveroutput on
declare
rc sys_refcursor;
lrow employees%rowtype; 
begin
    rc := MYPACK.Get_EmployeeByPage(2,3);    
    loop
      FETCH rc INTO lrow;
      exit when rc%notfound;      
      DBMS_OUTPUT.put_line (lrow.employee_id || '  '|| lrow.name);
    end loop;
    CLOSE rc;    --关闭游标
end;
   */
   FUNCTION Get_EmployeeByPage(v_pageidx number,v_pagesize number) return refcur
   IS
     rc refcur;
     v_offset number;
     v_sql varchar2(2000);
   BEGIN
      v_offset:=v_pagesize*(v_pageidx-1);
      v_sql := 'select * from employees offset :v_offset rows fetch next :v_pagesize rows only';
      open rc for v_sql using v_offset,v_pagesize;
      return rc;
   END;

   /*
   PROCEDURE Get_EmployeeByPage_P（）：分页方法获取员工表
   v_pageidx：页码，从1开始
   v_pagesize：每页的记录数量
   rc:返回的参照游标
   测试方法：
set serveroutput on
declare
rc sys_refcursor;
lrow employees%rowtype; 
begin
    MYPACK.Get_EmployeeByPage_P(1,3,rc);    
    loop
      FETCH rc INTO lrow;
      exit when rc%notfound;      
      DBMS_OUTPUT.put_line (lrow.employee_id || '  '|| lrow.name);
    end loop;
    CLOSE rc;    --关闭游标
end;
   */   
   PROCEDURE Get_EmployeeByPage_P(v_pageidx number,v_pagesize number,rc out refcur)
   IS
     v_offset number;
     v_sql varchar2(2000);
   BEGIN
      v_offset:=v_pagesize*(v_pageidx-1);
      v_sql := 'select * from employees offset :v_offset rows fetch next :v_pagesize rows only';
      open rc for v_sql using v_offset,v_pagesize;
   END;

/*
--更新订单表中每个订单的应收款。
--SELECT * FROM ORDERS WHERE ROWNUM<100
--UPDATE ORDERS SET TRADE_RECEIVABLE=0
BEGIN
MYPACK.Calc_All_TradeReceivable;
END;
*/
   PROCEDURE Calc_All_TradeReceivable
   IS
        m number(10,2);
   BEGIN
        FOR R IN (SELECT ORDER_ID FROM ORDERS)
        LOOP
          select sum(PRODUCT_NUM*PRODUCT_PRICE) into m from ORDER_DETAILS where ORDER_ID=R.ORDER_ID;
          if m is null then
            m:=0;
          end if;
          update ORDERS SET TRADE_RECEIVABLE=m-DISCOUNT WHERE ORDER_ID=R.ORDER_ID;
        END LOOP;
  END;

END MyPack;
/
